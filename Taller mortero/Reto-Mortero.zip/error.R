i = 1
totE_x = 0
totE_y = 0
totE_z = 0

repeat
{
  cat("error absoluto x ", abs(xx[i]-XX[i]), "y ",abs(yy[i]-YY[i]), "z ",abs(zz[i]-ZZ[i]),"error relativo x ",  abs(xx[i]-XX[i])/xx[i],"y " ,abs(yy[i]-YY[i])/yy[i], "z ",abs(zz[i]-ZZ[i])/zz[i],"i ",i,"\n")
  if(!is.na(abs(xx[i]-XX[i])/xx[i])  && !is.infinite(abs(xx[i]-XX[i])/xx[i]))
    totE_x = totE_x + abs(xx[i]-XX[i])/xx[i]
  if(!is.na(abs(yy[i]-YY[i])/yy[i]) && !is.infinite(abs(yy[i]-YY[i])/yy[i]))
    totE_y = totE_y + abs(yy[i]-YY[i])/yy[i]
  if(!is.na(abs(zz[i]-ZZ[i])/zz[i]) && !is.infinite(abs(zz[i]-ZZ[i])/zz[i]))
    totE_z = totE_z + abs(zz[i]-ZZ[i])/zz[i]
  i = i + 1
  if(length(xx)+1 == i )
    break;
}

i = 1
repeat
{
  cat("error absoluto x ", abs(xxx[i]-XXX[i]), "y ",abs(yyy[i]-YYY[i]), "z ",abs(zzz[i]-ZZZ[i]),"error relativo x ",  abs(xxx[i]-XXX[i])/xxx[i],"y " ,abs(yyy[i]-YYY[i])/yyy[i], "z ",abs(zzz[i]-ZZZ[i])/zzz[i],"i ",i,"\n")
  if(!is.na(abs(xxx[i]-XXX[i])/xxx[i]) && !is.infinite(abs(xxx[i]-XXX[i])/xxx[i]))
    totE_x = totE_x + abs(xxx[i]-XXX[i])/xxx[i]
  if(!is.na(abs(yyy[i]-YYY[i])/yyy[i]) && !is.infinite(abs(yyy[i]-YYY[i])/yyy[i]))
    totE_y = totE_y + abs(yyy[i]-YYY[i])/yyy[i]
  if(!is.na(abs(zzz[i]-ZZZ[i])/zzz[i]) && !is.infinite(abs(zzz[i]-ZZZ[i])/zzz[i]))
    totE_z = totE_z + abs(zzz[i]-ZZZ[i])/zzz[i]
  i = i + 1
  if(length(xxx)+1 == i )
    break;
}

i = 1
repeat
{
  cat("error absoluto x ", abs(xxxx[i]-XXXX[i]), "y ",abs(yyyy[i]-YYYY[i]), "z ",abs(zzzz[i]-ZZZZ[i]),"error relativo x ",  abs(xxxx[i]-XXXX[i])/xxxx[i],"y " ,abs(yyyy[i]-YYYY[i])/yyyy[i], "z ",abs(zzzz[i]-ZZZZ[i])/zzzz[i],"i ",i,"\n")
  if(!is.na(abs(xxxx[i]-XXXX[i])/xxxx[i]) && !is.infinite(abs(xxxx[i]-XXXX[i])/xxxx[i]))
    totE_x = totE_x + abs(xxxx[i]-XXXX[i])/xxxx[i]
  if(!is.na(abs(yyyy[i]-YYYY[i])/yyyy[i]) && !is.infinite(abs(yyyy[i]-YYYY[i])/yyyy[i]))
    totE_y = totE_y + abs(yyyy[i]-YYY[i])/yyyy[i]
  if(!is.na(abs(zzzz[i]-ZZZZ[i])/zzzz[i]) && !is.infinite(abs(zzzz[i]-ZZZZ[i])/zzzz[i]))
    totE_z = totE_z + abs(zzzz[i]-ZZZZ[i])/zzzz[i]
  i = i + 1
  if(length(xxxx)+1 == i )
    break;
}

cat("Error relativo en x es ", (totE_x*100)/length(xx), "\n")
cat("Error relativo en y es ", (totE_y*100)/length(xxx), "\n")
cat("Error relativo en z es ", (totE_z*100)/length(xxxx), "\n")

